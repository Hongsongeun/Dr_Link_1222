package dr_Link.dto;

public class DrLinkDTO {
	private String dl_name;
	private String dl_tel;
	private String dl_faxtel;
	
	public String getDl_name() {
		return dl_name;
	}
	public void setDl_name(String dl_name) {
		this.dl_name = dl_name;
	}
	public String getDl_tel() {
		return dl_tel;
	}
	public void setDl_tel(String dl_tel) {
		this.dl_tel = dl_tel;
	}
	public String getDl_faxtel() {
		return dl_faxtel;
	}
	public void setDl_faxtel(String dl_faxtel) {
		this.dl_faxtel = dl_faxtel;
	}
	
	


}
